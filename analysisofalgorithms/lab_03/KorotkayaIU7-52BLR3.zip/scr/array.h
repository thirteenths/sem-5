#pragma once

#include <iostream>
using namespace std;

class Array
{
public:
    Array() = default;
    explicit Array(int &n);
    ~Array();

    void randomArray();
    void inputArray();
    void outputArray();

    void sortBubble();
    void sortInsert();
    void sortShaker();

    //void beginTimeTest();

private:
    void swap(int &a, int &b);

private:
    int* array;
    int n = 0;
};