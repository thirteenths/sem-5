#ifndef _MATRIX_H_

#define _MATRIX_H_

#include "define.h"

void print_matrix(int matrix[LEN][LEN], int const count);

void fill_matrix(float matrix[LEN][LEN], int count, float num);

#endif