#ifndef _COLORS_H_

#define _COLORS_H_

#define red() printf("\33[31m")
#define green() printf("\33[32m")
#define yellow() printf("\33[33m")
#define blue() printf("\33[34m")
#define white() printf("\33[34m")
// #define white() printf("\33[37m")
#define blinks() printf("\33[5m");

#endif