#include <iostream>
#include "matrix.h"
using namespace std;

int main()
{
    int n, m;
    cout << "Введите n: ";
    cin >> n;
    cout << "Введите m: ";
    cin >> m;
    Matrix A(n,m);

    A.inputMatrix();
    
    cout << "Введите n: ";
    cin >> n;
    cout << "Введите m: ";
    cin >> m;
    Matrix B(n,m);

    B.inputMatrix();

    //cout << A.row() << B.column();

    Matrix M(A.row(), B.column());
    M.classicMultiplication(A, B);

    M.outputMatrix();

    Matrix N(A.row(), B.column());
    N.vinogradMultiplication(A, B);

    N.outputMatrix();

    Matrix H(A.row(), B.column());
    H.vinogradMultiplication(A, B);

    H.outputMatrix();
}